import pandas as pd
def convert:
    df = pd.read_csv("C:/Users/yunhy/Documents/UiPath/VisaManagement/data/csv/외국인 유학생 기초 자료 수집.csv")
    string = df.to_json(orient='records', force_ascii=False)
    return string